﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;


namespace Text__to__Speech_Converter_App
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("lets see how to Create a Text Converter ");
            // Step 1: Importing Required namespace ( predefine Framework Class Libraries/Functionalities - FCL) 
            // Step 2: Creating an Object  - (Instanciation) & Setting OutPut to Default Audio Devices()  
            // Step 3: Calling Fucntionality Speak() 

            SpeechSynthesizer spk = new SpeechSynthesizer();//Creating Object 
            spk.SetOutputToDefaultAudioDevice();
            string message = Console.ReadLine();//taking Input from the user 
            spk.Speak(message);
            Console.WriteLine("Here is the Output...!!");


        }
    }
}
