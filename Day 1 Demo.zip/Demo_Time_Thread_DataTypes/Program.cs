﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo_Time_Thread_DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with DataTypes in C# ");

            string name = "parth Shukla "; //In C# String is Reference type 
         // String MyName = new string();// This Will also Create a ref of String Classs 
            int Age = 20; // Int variable can store Integer values / value Type
            char Choice = 'Y'; // defined usin Single Quotes can store single Char / value Type
            //Boolean = true;    // Can store true and false ( 0 or 1) only  //Value Type
            float salary = 32.03f; //Can Store Float value//Value Type
            Double PF; //Cn store Double value upt two decimal precisions

            DateTime todaystime = new DateTime(); // Can store Date and Time both/
            //for displaying curent date and time we can use
            //
            todaystime = System.DateTime.Now;//Now is a Read only propoerty defined inside System.Datetime namepace
            Console.WriteLine("Current Date time is :"+todaystime);
            Thread.Sleep(5000);//We are using thread nmespace for pausing our system for 500 ms
            Console.WriteLine("Time after 5 Sec is :"+todaystime );



        }
    }
}
